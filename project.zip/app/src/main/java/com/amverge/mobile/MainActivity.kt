package com.amverge.mobile

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMetadataRetriever
import android.media.MediaMuxer
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.provider.OpenableColumns
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.nio.ByteBuffer

// ---------- المنطق: تحليل المشاهد (نفس فكرة AMVerge: الإطارات المفتاحية) ----------

data class Scene(val start: Long, val end: Long)
class Analysis(val keyframes: List<Long>, val durationUs: Long)

fun analyze(ctx: Context, uri: Uri): Analysis {
    val ex = MediaExtractor()
    try {
        ex.setDataSource(ctx, uri, null)
        var track = -1
        var dur = 0L
        for (i in 0 until ex.trackCount) {
            val f = ex.getTrackFormat(i)
            if (f.getString(MediaFormat.KEY_MIME)?.startsWith("video/") == true) {
                track = i
                if (f.containsKey(MediaFormat.KEY_DURATION)) dur = f.getLong(MediaFormat.KEY_DURATION)
                break
            }
        }
        require(track >= 0) { "لا يوجد مسار فيديو" }
        ex.selectTrack(track)
        val keys = ArrayList<Long>()
        while (true) {
            val t = ex.sampleTime
            if (t < 0) break
            if ((ex.sampleFlags and MediaExtractor.SAMPLE_FLAG_SYNC) != 0) keys.add(t)
            if (!ex.advance()) break
        }
        if (keys.isEmpty()) keys.add(0L)
        if (dur <= 0) dur = keys.last() + 1_000_000
        return Analysis(keys, dur)
    } finally {
        ex.release()
    }
}

// دمج المشاهد القصيرة (يعادل أداة الدمج لإصلاح القطع الخاطئة)
fun buildScenes(a: Analysis, minSec: Float): List<Scene> {
    val minUs = (minSec * 1_000_000).toLong()
    val starts = ArrayList<Long>()
    for (k in a.keyframes) {
        if (starts.isEmpty() || k - starts.last() >= minUs) starts.add(k)
    }
    return starts.mapIndexed { i, s ->
        Scene(s, if (i + 1 < starts.size) starts[i + 1] else a.durationUs)
    }
}

// ---------- التصدير بدون إعادة ترميز (سريع وبنفس الجودة) ----------

fun exportScene(ctx: Context, src: Uri, scene: Scene, name: String) {
    val resolver = ctx.contentResolver
    val values = ContentValues().apply {
        put(MediaStore.Video.Media.DISPLAY_NAME, "$name.mp4")
        put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
        put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/AMVerge")
        put(MediaStore.Video.Media.IS_PENDING, 1)
    }
    val out = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
        ?: throw IllegalStateException("تعذر إنشاء الملف")
    val ex = MediaExtractor()
    try {
        ex.setDataSource(ctx, src, null)
        resolver.openFileDescriptor(out, "w")!!.use { pfd ->
            val m = MediaMuxer(pfd.fileDescriptor, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            try {
                val map = HashMap<Int, Int>()
                for (i in 0 until ex.trackCount) {
                    val f = ex.getTrackFormat(i)
                    val mime = f.getString(MediaFormat.KEY_MIME) ?: continue
                    if (mime.startsWith("video/") || mime.startsWith("audio/")) {
                        if (mime.startsWith("video/") && f.containsKey(MediaFormat.KEY_ROTATION)) {
                            m.setOrientationHint(f.getInteger(MediaFormat.KEY_ROTATION))
                        }
                        map[i] = m.addTrack(f)
                        ex.selectTrack(i)
                    }
                }
                m.start()
                ex.seekTo(scene.start, MediaExtractor.SEEK_TO_PREVIOUS_SYNC)
                val buf = ByteBuffer.allocate(8 * 1024 * 1024)
                val info = MediaCodec.BufferInfo()
                while (true) {
                    val t = ex.sampleTime
                    if (t < 0 || t >= scene.end) break
                    val size = ex.readSampleData(buf, 0)
                    if (size < 0) break
                    val flags = if ((ex.sampleFlags and MediaExtractor.SAMPLE_FLAG_SYNC) != 0)
                        MediaCodec.BUFFER_FLAG_KEY_FRAME else 0
                    info.set(0, size, maxOf(0L, t - scene.start), flags)
                    map[ex.sampleTrackIndex]?.let { m.writeSampleData(it, buf, info) }
                    ex.advance()
                }
                m.stop()
            } finally {
                m.release()
            }
        }
        values.clear()
        values.put(MediaStore.Video.Media.IS_PENDING, 0)
        resolver.update(out, values, null, null)
    } catch (e: Exception) {
        resolver.delete(out, null, null)
        throw e
    } finally {
        ex.release()
    }
}

fun thumb(ctx: Context, uri: Uri, us: Long): Bitmap? {
    val r = MediaMetadataRetriever()
    return try {
        r.setDataSource(ctx, uri)
        r.getFrameAtTime(us, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)?.let {
            Bitmap.createScaledBitmap(it, 320, (320f * it.height / it.width).toInt().coerceAtLeast(1), true)
        }
    } catch (e: Exception) {
        null
    } finally {
        r.release()
    }
}

fun displayName(ctx: Context, uri: Uri): String =
    ctx.contentResolver.query(uri, null, null, null, null)?.use { c ->
        val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
        if (i >= 0 && c.moveToFirst()) c.getString(i) else null
    } ?: "video"

fun fmt(us: Long): String {
    val s = us / 1_000_000
    return "%d:%02d".format(s / 60, s % 60)
}

// ---------- الواجهة ----------

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                Surface(Modifier.fillMaxSize()) { App() }
            }
        }
    }
}

@Composable
fun App() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var uri by remember { mutableStateOf<Uri?>(null) }
    var name by remember { mutableStateOf("") }
    var analysis by remember { mutableStateOf<Analysis?>(null) }
    var minSec by remember { mutableStateOf(5f) }
    var status by remember { mutableStateOf("اختر فيديو للبدء") }
    var busy by remember { mutableStateOf(false) }
    val selected = remember { mutableStateListOf<Int>() }
    val scenes = remember(analysis, minSec) {
        analysis?.let { buildScenes(it, minSec) } ?: emptyList()
    }
    LaunchedEffect(scenes) { selected.clear() }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        if (u != null) {
            uri = u
            name = displayName(ctx, u)
            analysis = null
            busy = true
            status = "جاري تحليل الفيديو..."
            scope.launch {
                try {
                    analysis = withContext(Dispatchers.IO) { analyze(ctx, u) }
                    status = "تم التحليل. اختر المشاهد ثم صدّر"
                } catch (e: Exception) {
                    status = "فشل التحليل: ${e.message}"
                }
                busy = false
            }
        }
    }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("AMVerge Mobile", style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.size(8.dp))
        Button(onClick = { picker.launch(arrayOf("video/*")) }, enabled = !busy) {
            Text("اختيار فيديو")
        }
        if (name.isNotEmpty()) Text(name)
        Text(status)

        if (analysis != null) {
            Text("دمج المشاهد الأقصر من ${minSec.toInt()} ثانية")
            Slider(value = minSec, onValueChange = { minSec = it }, valueRange = 0f..60f)
            Text("عدد المشاهد: ${scenes.size}  |  المحدد: ${selected.size}")
            Row {
                OutlinedButton(onClick = {
                    selected.clear()
                    selected.addAll(scenes.indices)
                }) { Text("تحديد الكل") }
                Spacer(Modifier.width(8.dp))
                Button(
                    enabled = !busy && selected.isNotEmpty(),
                    onClick = {
                        val u = uri
                        if (u != null) {
                            busy = true
                            val list = selected.sorted().map { it to scenes[it] }
                            val base = name.substringBeforeLast('.')
                                .replace(Regex("[\\\\/:*?\"<>|]"), "_")
                            scope.launch {
                                try {
                                    list.forEachIndexed { n, (idx, sc) ->
                                        status = "تصدير ${n + 1} من ${list.size}..."
                                        withContext(Dispatchers.IO) {
                                            exportScene(ctx, u, sc, "${base}_scene${idx + 1}")
                                        }
                                    }
                                    status = "تم! الملفات في Movies/AMVerge"
                                } catch (e: Exception) {
                                    status = "فشل التصدير: ${e.message}"
                                }
                                busy = false
                            }
                        }
                    }
                ) { Text("تصدير المحدد") }
            }
        }

        val u = uri
        if (u != null) {
            LazyColumn(Modifier.weight(1f)) {
                itemsIndexed(scenes) { i, s ->
                    SceneRow(u, i, s, i in selected) {
                        if (i in selected) selected.remove(i) else selected.add(i)
                    }
                }
            }
        }
    }
}

@Composable
fun SceneRow(uri: Uri, index: Int, scene: Scene, checked: Boolean, onToggle: () -> Unit) {
    val ctx = LocalContext.current
    val bmp by produceState<Bitmap?>(null, uri, scene.start) {
        value = withContext(Dispatchers.IO) { thumb(ctx, uri, scene.start) }
    }
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onToggle).padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Checkbox(checked = checked, onCheckedChange = { onToggle() })
        Box(Modifier.size(width = 120.dp, height = 68.dp)) {
            bmp?.let {
                Image(
                    it.asImageBitmap(), null,
                    Modifier.fillMaxSize(), contentScale = ContentScale.Crop
                )
            }
        }
        Spacer(Modifier.width(12.dp))
        Column {
            Text("مشهد ${index + 1}")
            Text("${fmt(scene.start)} - ${fmt(scene.end)}")
        }
    }
}
