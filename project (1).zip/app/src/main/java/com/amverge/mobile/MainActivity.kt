package com.amverge.mobile

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMetadataRetriever
import android.media.MediaMuxer
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.widget.VideoView
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.nio.ByteBuffer

// ---------- المنطق ----------

data class Scene(val start: Long, val end: Long)
class Analysis(val keyframes: List<Long>, val durationUs: Long)

fun analyze(ctx: Context, uri: Uri): Analysis {
    val ex = MediaExtractor()
    try {
        ex.setDataSource(ctx, uri, null)
        var track = -1
        var dur = 0L
        for (i in 0 until ex.trackCount) {
            val f = ex.getTrackFormat(i)
            if (f.getString(MediaFormat.KEY_MIME)?.startsWith("video/") == true) {
                track = i
                if (f.containsKey(MediaFormat.KEY_DURATION)) dur = f.getLong(MediaFormat.KEY_DURATION)
                break
            }
        }
        require(track >= 0) { "لا يوجد مسار فيديو" }
        ex.selectTrack(track)
        val keys = ArrayList<Long>()
        while (true) {
            val t = ex.sampleTime
            if (t < 0) break
            if ((ex.sampleFlags and MediaExtractor.SAMPLE_FLAG_SYNC) != 0) keys.add(t)
            if (!ex.advance()) break
        }
        if (keys.isEmpty()) keys.add(0L)
        if (dur <= 0) dur = keys.last() + 1_000_000
        return Analysis(keys, dur)
    } finally {
        ex.release()
    }
}

fun buildScenes(a: Analysis, minSec: Float): List<Scene> {
    val minUs = (minSec * 1_000_000).toLong()
    val starts = ArrayList<Long>()
    for (k in a.keyframes) if (starts.isEmpty() || k - starts.last() >= minUs) starts.add(k)
    return starts.mapIndexed { i, s ->
        Scene(s, if (i + 1 < starts.size) starts[i + 1] else a.durationUs)
    }
}

// تصدير مشهد واحد أو دمج عدة مشاهد في ملف واحد (بدون إعادة ترميز)
fun exportScenes(ctx: Context, src: Uri, list: List<Scene>, name: String) {
    val resolver = ctx.contentResolver
    val values = ContentValues().apply {
        put(MediaStore.Video.Media.DISPLAY_NAME, "$name.mp4")
        put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
        put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/AMVspace")
        put(MediaStore.Video.Media.IS_PENDING, 1)
    }
    val out = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
        ?: throw IllegalStateException("تعذر إنشاء الملف")
    val ex = MediaExtractor()
    try {
        ex.setDataSource(ctx, src, null)
        resolver.openFileDescriptor(out, "w")!!.use { pfd ->
            val m = MediaMuxer(pfd.fileDescriptor, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            try {
                val map = HashMap<Int, Int>()
                for (i in 0 until ex.trackCount) {
                    val f = ex.getTrackFormat(i)
                    val mime = f.getString(MediaFormat.KEY_MIME) ?: continue
                    if (mime.startsWith("video/") || mime.startsWith("audio/")) {
                        if (mime.startsWith("video/") && f.containsKey(MediaFormat.KEY_ROTATION)) {
                            m.setOrientationHint(f.getInteger(MediaFormat.KEY_ROTATION))
                        }
                        map[i] = m.addTrack(f)
                        ex.selectTrack(i)
                    }
                }
                m.start()
                val buf = ByteBuffer.allocate(8 * 1024 * 1024)
                val info = MediaCodec.BufferInfo()
                var offset = 0L
                for (sc in list) {
                    ex.seekTo(sc.start, MediaExtractor.SEEK_TO_PREVIOUS_SYNC)
                    while (true) {
                        val t = ex.sampleTime
                        if (t < 0 || t >= sc.end) break
                        val size = ex.readSampleData(buf, 0)
                        if (size < 0) break
                        val flags = if ((ex.sampleFlags and MediaExtractor.SAMPLE_FLAG_SYNC) != 0)
                            MediaCodec.BUFFER_FLAG_KEY_FRAME else 0
                        info.set(0, size, maxOf(0L, t - sc.start) + offset, flags)
                        map[ex.sampleTrackIndex]?.let { m.writeSampleData(it, buf, info) }
                        ex.advance()
                    }
                    offset += sc.end - sc.start
                }
                m.stop()
            } finally {
                m.release()
            }
        }
        values.clear()
        values.put(MediaStore.Video.Media.IS_PENDING, 0)
        resolver.update(out, values, null, null)
    } catch (e: Exception) {
        resolver.delete(out, null, null)
        throw e
    } finally {
        ex.release()
    }
}

fun thumb(ctx: Context, uri: Uri, us: Long): Bitmap? {
    val r = MediaMetadataRetriever()
    return try {
        r.setDataSource(ctx, uri)
        r.getFrameAtTime(us, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)?.let {
            Bitmap.createScaledBitmap(it, 320, (320f * it.height / it.width).toInt().coerceAtLeast(1), true)
        }
    } catch (e: Exception) {
        null
    } finally {
        r.release()
    }
}

fun displayName(ctx: Context, uri: Uri): String =
    ctx.contentResolver.query(uri, null, null, null, null)?.use { c ->
        val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
        if (i >= 0 && c.moveToFirst()) c.getString(i) else null
    } ?: "video"

fun fmt(us: Long): String {
    val s = us / 1_000_000
    return "%d:%02d".format(s / 60, s % 60)
}

// ---------- الثيم: أسود + بنفسجي + أبيض ----------

private val Purple = Color(0xFFA855F7)

@Composable
fun AMVTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Purple, onPrimary = Color.White,
            background = Color.Black, onBackground = Color.White,
            surface = Color(0xFF0D0716), onSurface = Color.White,
            surfaceVariant = Color(0xFF150E22), outline = Color(0xFF6D3FB0)
        ),
        content = content
    )
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            AMVTheme {
                Surface(Modifier.fillMaxSize(), color = Color.Black) { App() }
            }
        }
    }
}

@Composable
fun App() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var uri by remember { mutableStateOf<Uri?>(null) }
    var name by remember { mutableStateOf("") }
    var analysis by remember { mutableStateOf<Analysis?>(null) }
    var minSec by remember { mutableStateOf(5f) }
    var status by remember { mutableStateOf("اختر فيديو للبدء") }
    var busy by remember { mutableStateOf(false) }
    var preview by remember { mutableStateOf<Scene?>(null) }
    val selected = remember { mutableStateListOf<Int>() }
    val scenes = remember(analysis, minSec) {
        analysis?.let { buildScenes(it, minSec) } ?: emptyList()
    }
    LaunchedEffect(scenes) { selected.clear() }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        if (u != null) {
            uri = u
            name = displayName(ctx, u)
            analysis = null
            busy = true
            status = "جاري تحليل الفيديو..."
            scope.launch {
                try {
                    analysis = withContext(Dispatchers.IO) { analyze(ctx, u) }
                    status = "تم التحليل. اضغط على الصورة للمعاينة"
                } catch (e: Exception) {
                    status = "فشل التحليل: ${e.message}"
                }
                busy = false
            }
        }
    }

    fun run(merge: Boolean) {
        val u = uri ?: return
        val idxs = selected.sorted()
        val base = name.substringBeforeLast('.').replace(Regex("[\\\\/:*?\"<>|]"), "_")
        busy = true
        scope.launch {
            try {
                if (merge) {
                    status = "جاري الدمج..."
                    withContext(Dispatchers.IO) {
                        exportScenes(ctx, u, idxs.map { scenes[it] }, "${base}_merged")
                    }
                } else {
                    idxs.forEachIndexed { n, idx ->
                        status = "تصدير ${n + 1} من ${idxs.size}..."
                        withContext(Dispatchers.IO) {
                            exportScenes(ctx, u, listOf(scenes[idx]), "${base}_scene${idx + 1}")
                        }
                    }
                }
                status = "تم! الملفات في Movies/AMVspace"
            } catch (e: Exception) {
                status = "فشل: ${e.message}"
            }
            busy = false
        }
    }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("AMV", fontSize = 30.sp, fontWeight = FontWeight.Bold, color = Color.White)
            Text("space", fontSize = 30.sp, fontWeight = FontWeight.Bold, color = Purple)
        }
        Spacer(Modifier.height(10.dp))
        Button(onClick = { picker.launch(arrayOf("video/*")) }, enabled = !busy) {
            Text("اختيار فيديو")
        }
        if (name.isNotEmpty()) Text(name, Modifier.padding(top = 8.dp), color = Color.White)
        Text(status, color = Purple)

        if (analysis != null) {
            Spacer(Modifier.height(8.dp))
            Text("دمج المشاهد الأقصر من ${minSec.toInt()} ثانية")
            Slider(
                value = minSec, onValueChange = { minSec = it }, valueRange = 0f..60f,
                colors = SliderDefaults.colors(inactiveTrackColor = Color(0xFF2A1A44))
            )
            Text("المشاهد: ${scenes.size}   |   المحدد: ${selected.size}", color = Purple)
            Spacer(Modifier.height(6.dp))
            Row {
                OutlinedButton(onClick = {
                    selected.clear(); selected.addAll(scenes.indices)
                }) { Text("تحديد الكل") }
                Spacer(Modifier.width(8.dp))
                Button(enabled = !busy && selected.isNotEmpty(), onClick = { run(false) }) {
                    Text("تصدير منفصل")
                }
            }
            Button(
                enabled = !busy && selected.size > 1,
                onClick = { run(true) },
                modifier = Modifier.fillMaxWidth().padding(top = 6.dp)
            ) { Text("دمج المحدد في ملف واحد") }
        }

        val u = uri
        if (u != null) {
            Spacer(Modifier.height(8.dp))
            LazyColumn(Modifier.weight(1f)) {
                itemsIndexed(scenes) { i, s ->
                    SceneRow(u, i, s, i in selected, onPreview = { preview = s }) {
                        if (i in selected) selected.remove(i) else selected.add(i)
                    }
                }
            }
        }
    }

    val p = preview
    val u2 = uri
    if (p != null && u2 != null) PreviewDialog(u2, p) { preview = null }
}

@Composable
fun SceneRow(
    uri: Uri, index: Int, scene: Scene, checked: Boolean,
    onPreview: () -> Unit, onToggle: () -> Unit
) {
    val ctx = LocalContext.current
    val bmp by produceState<Bitmap?>(null, uri, scene.start) {
        value = withContext(Dispatchers.IO) { thumb(ctx, uri, scene.start) }
    }
    Surface(
        Modifier.fillMaxWidth().padding(vertical = 4.dp).clickable(onClick = onToggle),
        shape = RoundedCornerShape(12.dp),
        color = MaterialTheme.colorScheme.surfaceVariant
    ) {
        Row(Modifier.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            Checkbox(checked = checked, onCheckedChange = { onToggle() })
            Box(
                Modifier.size(width = 120.dp, height = 68.dp)
                    .clip(RoundedCornerShape(8.dp)).background(Color.Black)
                    .clickable(onClick = onPreview),
                contentAlignment = Alignment.Center
            ) {
                bmp?.let {
                    Image(it.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                }
                Text("▶", color = Color.White, fontSize = 24.sp)
            }
            Spacer(Modifier.width(12.dp))
            Column {
                Text("مشهد ${index + 1}", color = Purple, fontWeight = FontWeight.Bold)
                Text("${fmt(scene.start)} - ${fmt(scene.end)}", color = Color.White)
            }
        }
    }
}

@Composable
fun PreviewDialog(uri: Uri, scene: Scene, onClose: () -> Unit) {
    val h = remember { Handler(Looper.getMainLooper()) }
    DisposableEffect(Unit) { onDispose { h.removeCallbacksAndMessages(null) } }
    val s = (scene.start / 1000).toInt()
    val e = (scene.end / 1000).toInt()
    AlertDialog(
        onDismissRequest = onClose,
        confirmButton = { TextButton(onClick = onClose) { Text("إغلاق", color = Purple) } },
        text = {
            AndroidView(
                modifier = Modifier.fillMaxWidth().height(220.dp),
                factory = { c ->
                    VideoView(c).also { v ->
                        v.setVideoURI(uri)
                        v.setOnPreparedListener { v.seekTo(s); v.start() }
                        h.post(object : Runnable {
                            override fun run() {
                                if (v.isPlaying && v.currentPosition >= e) v.seekTo(s)
                                h.postDelayed(this, 200)
                            }
                        })
                    }
                }
            )
        }
    )
}
